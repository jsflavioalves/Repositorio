-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:45 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id_emails` int(10) NOT NULL auto_increment,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `data` varchar(10) NOT NULL,
  `hora` varchar(8) NOT NULL,
  PRIMARY KEY  (`id_emails`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=110 ;

--
-- Extraindo dados da tabela `emails`
--

INSERT INTO `emails` (`id_emails`, `nome`, `email`, `data`, `hora`) VALUES
(1, 'Alan Chrystian', 'allanchrystian90@gmail.com', '09/11/2016', '15:04:22'),
(2, 'Mauricio Abreu', 'allanchrystian1999@gmail.com', '10/11/2016', '16:38:40'),
(3, 'Ken Esparta Ccorahua', 'nek.112358@gmail.com', '23/11/2016', '22:41:15'),
(4, 'JoÃ£o Rafael Barbosa de Araujo', 'rafael.acurcio@gmail.com', '23/11/2016', '23:12:33'),
(5, 'JANUSIA MARIA FREITAS DA SILVA', 'janusiafreitas@outlook.com', '02/12/2016', '09:33:49'),
(6, 'JANAILDE COSTA FERNANDES', 'janailde.fernandes@gmail.com', '11/12/2016', '16:34:05'),
(7, 'Giovanni Bruno da Silva Luz', 'giovannibrunoluz@gmail.com', '20/12/2016', '15:17:21'),
(8, 'Erivelton Menezes', 'eriveltonmenezes01@gmail.com', '13/01/2017', '11:06:58'),
(9, 'Lucas Anderson Oliveira GuimarÃ£es', 'laogcfc@gmail.com', '23/01/2017', '17:44:21'),
(10, 'Luiz Paulo Lima da Silva', 'luizlima21@hotmail.com', '25/01/2017', '20:06:36'),
(11, 'LUCIANA COELHO PONTE', 'lucianaponte@yahoo.com.br', '04/02/2017', '19:36:45'),
(12, 'Mateus Lima Cajado', 'mateus.lc@alu.ufc.br', '14/02/2017', '11:55:26'),
(13, 'Maria silvelane estevam da silva ', 'silvelane18@gmail.com', '14/02/2017', '13:09:24'),
(14, 'Priscila Alves de Oliveira', 'priie-oliveira@hotmail.com', '14/02/2017', '13:22:49'),
(15, 'Giovanna Figueiredo Ribeiro', 'giovannafribeiro@gmail.com', '16/02/2017', '16:21:45'),
(16, 'Bianca Maria', 'biancampvieira@gmail.com', '20/02/2017', '20:43:44'),
(17, 'Sarah Sucupira', 'sarah.sucupira@hotmail.com', '03/03/2017', '12:13:05'),
(18, 'gabriel aguiar feitosa', 'gabrielaguiarfeitosa@gmail.com', '03/03/2017', '15:31:05'),
(19, 'AntÃ´nio Anderson Fonseca de Sousa', 'ant.andersonsousa@outlook.com', '04/03/2017', '22:52:38'),
(20, 'Lucas Monte da Costa Moreno', 'lluccasmoreno@hotmail.com', '05/03/2017', '01:24:47'),
(21, 'Bruno Rafael', 'rafael.academico.ufc@gmail.com', '09/03/2017', '11:17:18'),
(22, 'JÃºlia QueirÃ³s Vieira', 'julia-ruth@hotmail.com', '10/03/2017', '00:44:07'),
(23, 'FlÃ¡vio Cavalcanti', 'favocav@gmail.com', '10/03/2017', '08:54:30'),
(24, 'FABIO CHAVES', 'komodo2000@hotmail.com', '14/03/2017', '13:01:02'),
(25, 'Fernando Luciano Barros Xavier', 'sempatrocinio@yahoo.com.br', '16/03/2017', '06:14:51'),
(26, 'Marcello Camelo Alcanfor MagalhÃ£es', 'marcellocamelo@bol.com.br', '26/03/2017', '14:51:17'),
(27, 'VIRGINIA BARBOSA DA SILVA', 'virginiavmi05@gmail.com', '29/03/2017', '14:02:56'),
(28, 'Ruana Silva Sousa', 'ruanasousa15@gmail.com', '04/04/2017', '11:18:34'),
(29, 'LuÃ­s', 'luis@terasolucoes.com', '05/04/2017', '10:13:53'),
(30, 'Maria Elane', 'antonella_antonio@hotmail.com', '10/04/2017', '08:29:47'),
(31, 'KÃ©bia Sucupira', 'kebiasucupira@gmail.com', '18/04/2017', '10:18:19'),
(32, 'Lara Beatriz Oliveira de Araujo', 'lara.oliveiraaraujo@outlook.com', '18/04/2017', '11:31:53'),
(33, 'Fabiano Dias Freire', 'fabcrat68@gmail.com', '26/04/2017', '13:07:24'),
(34, '', '', '03/05/2017', '00:08:54'),
(35, 'Leonardo Duarte', 'leledudu1@hotmail.com', '04/05/2017', '09:09:48'),
(36, '', '', '22/05/2017', '12:08:47'),
(37, '', '', '27/05/2017', '04:39:28'),
(38, 'Ian Ariel Barbosa Nunes', 'ian_abn@hotmail.com', '08/06/2017', '12:03:25'),
(39, '', '', '10/06/2017', '22:02:47'),
(40, '', '', '14/06/2017', '03:46:57'),
(41, '', '', '15/06/2017', '11:22:47'),
(42, '', '', '23/06/2017', '00:20:00'),
(43, '', '', '26/06/2017', '09:37:20'),
(44, '', '', '27/06/2017', '20:39:58'),
(45, 'ivina soares', 'soaresivina@gmail.com', '12/07/2017', '21:10:03'),
(46, '', '', '13/07/2017', '20:07:40'),
(47, '', '', '15/07/2017', '04:05:37'),
(48, '', '', '29/07/2017', '19:50:07'),
(49, 'Sabrina Alves de Oliveira Alencar', 'sa_alencar13@hotmail.com', '03/08/2017', '11:50:28'),
(50, 'Marisa Lima de Vasconcelos', 'marisa182009@gmail.com', '04/08/2017', '16:59:30'),
(51, 'Bruna Adriano de Vasconcelos', 'brunaadvasconcelos@hotmail.com', '04/08/2017', '18:01:46'),
(52, 'Anderson Gomes Agostinho', 'andersongomes@alu.ufc.br', '04/08/2017', '18:35:00'),
(53, 'samuel santiago carvalho de britto', 'samuel21@hotmail.com.br', '04/08/2017', '22:44:02'),
(54, 'Barbara Maria Carvalho Batista Lima', 'barbara.lima_2012@hotmail.com', '06/08/2017', '23:26:02'),
(55, 'JOSE NICOLAS DE OLIVEIRA', 'nicollas@globomail.com', '07/08/2017', '09:03:23'),
(56, 'rana pequeno franÃ§a', 'maxrana4@hotmail.com', '07/08/2017', '09:09:15'),
(57, 'Jamilly Ferreira Oliveira', 'jamilly_regia@hotmail.com', '07/08/2017', '10:30:21'),
(58, 'Antonio Emerson Fernandes Bonfim', 'emersonfbprod@gmail.com', '07/08/2017', '11:06:52'),
(59, 'jordam marques de paiva', 'jordam.m12@gmail.com', '07/08/2017', '12:31:59'),
(60, 'Anna Carolina Cordeiro de Sena', 'karolsena86@gmail.com', '08/08/2017', '09:50:03'),
(61, 'EUDEMBERG MONTEIRO DA SILVA', 'godsonjc@gmail.com', '08/08/2017', '15:43:45'),
(62, 'Gabriela Ellen de Sousa Vidal', 'gabrielaellen48@gmail.com', '08/08/2017', '18:21:33'),
(63, 'Carmem Helena Fortes', 'carmenhfortes97@gmail.com', '09/08/2017', '20:40:03'),
(64, 'Walesca Alves Siqueira', 'lescasiqueira@yahoo.com.br', '10/08/2017', '10:16:42'),
(65, 'FRANCISCO HALLISON FREIRE', 'hallisonfreire@gmail.com', '10/08/2017', '19:45:39'),
(66, '', '', '11/08/2017', '00:25:32'),
(67, 'Eduardo da ConceiÃ§Ã£o Rodrigues', 'eduardo.rodrigues@alu.ufc.br', '11/08/2017', '13:47:58'),
(68, 'ivina soares de oliveira arruda', 'soaresivina@gmail.com', '11/08/2017', '22:10:47'),
(69, 'Danielle Schmid Brigido', 'danisbrigido@gmail.com', '14/08/2017', '20:43:13'),
(70, 'FRANCISCO LUCAS DA SILVA GOMES', 'lucasgomes@alu.ufc.br', '15/08/2017', '14:08:38'),
(71, 'Ana Karolina', 'anakarolinamacedo@hotmail.com', '17/08/2017', '19:13:07'),
(72, 'Maria Alice Tabosa de Lima', 'alicelima122@gmail.com', '18/08/2017', '20:57:31'),
(73, 'Wenderson RebouÃ§as da SIlva', 'wendersonreboucas@gmail.com', '19/08/2017', '16:55:52'),
(74, 'Erika Peixoto', 'erika@auraconsultoria.com.br', '22/08/2017', '10:44:30'),
(75, 'jonh lucas costa silva', 'jonhlucas1706@gmail.com', '22/08/2017', '23:27:17'),
(76, 'DiÃªgo Yslan Almeida Estevam', 'diegoyslan@alu.ufc.br', '23/08/2017', '13:17:13'),
(77, 'Thomas Natson Beserra Calixto', 'thomasldp2012@gmail.com', '23/08/2017', '15:44:40'),
(78, '', '', '27/08/2017', '20:23:32'),
(79, 'Rayanne MagalhÃ£es FalcÃ£o', 'rayanne21falcao@gmail.com', '03/09/2017', '18:13:17'),
(80, 'Adrya Santos Albuquerque', 'adrya.alb@gmail.com', '04/09/2017', '10:54:31'),
(81, 'Vicente Emanuel Ribeiro Macedo Alves', 'vincent-e13@hotmail.com', '04/09/2017', '13:31:10'),
(83, '', '', '06/09/2017', '01:55:02'),
(84, '', '', '11/09/2017', '09:35:12'),
(85, 'Manoel Alves da Silva', 'manoelfortal27@gmail.com', '14/09/2017', '16:07:42'),
(86, 'BÃ¡rbara Imaculada AraÃºjo de Oliveira', 'binha.imaculada@gmail.com', '17/09/2017', '19:18:53'),
(87, '', '', '26/09/2017', '07:08:21'),
(88, 'Sergio', 'sergio1pj@outlook.com', '27/09/2017', '15:12:15'),
(89, 'caio victor fernandes de oliveira', 'caiovictorfernandesdeoliveira@gmail.com', '05/10/2017', '09:56:50'),
(90, '', '', '11/10/2017', '05:26:09'),
(91, '', '', '28/10/2017', '03:23:36'),
(92, '', '', '12/11/2017', '07:19:23'),
(93, '', '', '28/11/2017', '08:26:13'),
(94, '', '', '14/12/2017', '03:30:44'),
(95, '', '', '29/12/2017', '00:31:02'),
(96, '', '', '12/01/2018', '20:29:29'),
(97, '', '', '28/01/2018', '04:33:05'),
(98, '', '', '13/02/2018', '09:18:38'),
(99, '', '', '02/03/2018', '15:55:22'),
(100, '', '', '19/03/2018', '10:58:38'),
(101, '', '', '06/04/2018', '01:13:31'),
(102, '', '', '25/04/2018', '01:20:16'),
(103, '', '', '29/04/2018', '18:22:05'),
(104, '', '', '25/05/2018', '02:38:56'),
(105, '', '', '15/06/2018', '02:42:18'),
(106, '', '', '29/06/2018', '20:27:50'),
(107, '', '', '11/07/2018', '01:38:15'),
(108, '', '', '13/07/2018', '23:43:55'),
(109, '', '', '01/10/2018', '14:03:03');
