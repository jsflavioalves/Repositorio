-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:02 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `Rescisao`
--

CREATE TABLE IF NOT EXISTS `Rescisao` (
  `Nome_Alu` varchar(80) NOT NULL,
  `Matrícula_Alu` varchar(8) NOT NULL,
  `Avaliação_rescisão` varchar(1) NOT NULL,
  `avaliador` varchar(80) NOT NULL,
  `Observacoes` varchar(60) NOT NULL,
  `seq` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`seq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `Rescisao`
--

