-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:43 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `convenios_pendentes`
--

CREATE TABLE IF NOT EXISTS `convenios_pendentes` (
  `id_convenios_pendentes` int(10) NOT NULL auto_increment,
  `dt_abertura` varchar(10) collate utf8_unicode_ci NOT NULL,
  `processo` varchar(50) collate utf8_unicode_ci NOT NULL,
  `interessado` varchar(200) collate utf8_unicode_ci NOT NULL,
  `cnpj` varchar(100) collate utf8_unicode_ci NOT NULL,
  `saida_procuradoria` varchar(10) collate utf8_unicode_ci NOT NULL,
  `retorno_procuradoria` varchar(10) collate utf8_unicode_ci NOT NULL,
  `saida_prex` varchar(10) collate utf8_unicode_ci NOT NULL,
  `retorno_prex` varchar(10) collate utf8_unicode_ci NOT NULL,
  `pendencia` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data_arquivamento` varchar(30) collate utf8_unicode_ci NOT NULL,
  `data_email1` varchar(30) collate utf8_unicode_ci NOT NULL,
  `data_email2` varchar(30) collate utf8_unicode_ci NOT NULL,
  `observacao` varchar(100) collate utf8_unicode_ci NOT NULL,
  `arquivo` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_convenios_pendentes`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2774 ;

--
-- Extraindo dados da tabela `convenios_pendentes`
--

INSERT INTO `convenios_pendentes` (`id_convenios_pendentes`, `dt_abertura`, `processo`, `interessado`, `cnpj`, `saida_procuradoria`, `retorno_procuradoria`, `saida_prex`, `retorno_prex`, `pendencia`, `data_arquivamento`, `data_email1`, `data_email2`, `observacao`, `arquivo`) VALUES
(2653, '18/02/2016', '003873/16-71', 'Município de Limoeiro do Norte', '', '18/02/2016', '26/02/2016', '', '', 'No setor comp', '', '', '', '', ''),
(2652, '27/04/2016', '009690/16-69', 'Ministério Público do Estado do Ceará', '', '27/04/2016', '29/04/2016', '', '', 'Aberto nov', '', '', '', '', ''),
(2654, '08/03/2016', '005624/16-10', 'José Severino de Araújo', '', '08/03/2016', '16/03/2016', '', '', 'Certidão Trab. Positiva', '', '', '', '', ''),
(2666, '10/07/2017', '014199/17-31', 'EEM José Cláudio de Araújo', '', '10/07/2017', '17/07/2017', '', '', 'Recomendação da Procuradoria para celebração do convênio com o Governo do Estado do Ceará. Considera', '', '', '', '', ''),
(2681, '12/06/2017', '011864/17-34', 'REDE INDEPENDENTE DE JORNAIS DO NORDESTE LTDA', '', '12/06/2017', '19/06/2017', '', '', 'DOCUMENTAÇÃO INSUFICIENTE PARA IDENTIFICAÇÃO DO REPRESENTANTE DA EMPRESA', '', '', '', '', ''),
(2682, '30/05/2017', '010945/17-17', 'Cervejarias Kaisen Brasil', '', '30/05/2017', '07/06/2017', '', '', 'Pendência na Documentação', '', '', '', '', ''),
(2683, '17/04/2017', '007787/17-18', 'SECOVIMED Servico Social da Habitacao', '', '17/04/2017', '25/04/2017', '', '', 'Falta certidão da Receita Federal', '', '', '', '', ''),
(2685, '09/02/2017', '002974/17-13', 'Gracom Comercio e Serviços de Escola de Informatica e Treinamento', '', '09/02/2017', '14/02/2017', '', '', 'Contrato Social e Certidão Receita Federal', '', '', '', '', ''),
(2686, '04/01/2017', '007351/16-01', 'UNILAB - Universidade de Integração Internacional da Lusofonia Afrobrasileira', '', '04/01/2017', '11/01/2017', '', '', 'Processo aberto pela Unilab com Nro 23282.007351/2016-01', '', '', '', '', ''),
(2687, '13/12/2016', '025930/16-72', 'Marquise Empreendimentos S/A', '', '13/12/2016', '15/03/2017', '', '', 'Falta portaria de Nomeacao', '', '', '', '', ''),
(2688, '08/12/2016', '025611/16-67', 'Tche Black Bar Espetinhos', '', '21/03/2017', '28/03/2017', '', '', 'certidao da receita federal', '', '', '', '', ''),
(2689, '30/11/2016', '025004/16-05', 'BASE AEREA DE FORTALEZA', '', '30/11/2016', '05/12/2016', '', '', 'Vide Parecer', '', '', '', '', ''),
(2690, '01/09/2016', '023277/16-15', 'Controlpax Audditoria & Consultoria LTDA-ME', '', '01/09/2016', '17/11/2016', '', '', 'Falta procuração e contrato social', '', '', '', '', ''),
(2691, '26/07/2016', '016369/16-31', 'Instituto Compartilha/HEMOCE', '', '26/07/2016', '22/08/2016', '', '', 'Vide parecer', '', '', '', '', ''),
(2692, '27/06/2016', '014248/16-54', 'Alexandre Jacques Bottan', '', '27/06/2016', '04/07/2016', '', '', 'rejeitado pela procuradoria', '', '', '', '', ''),
(2693, '13/06/2016', '013333/16-03', 'Costa Mendes Delicatessem ', '', '13/06/2016', '20/06/2016', '', '', 'ver parece', '', '', '', '', ''),
(2694, '04/09/2017', '018318/17-24', 'Associação Viva o Badminton Sertão Central', '', '04/09/2017', '18/09/2017', '', '', 'CNPJ colocado foi outra PJ não a da Associação - Parecer Proc', '', '18/09/2017', '', 'Email enviado para empresa em 18 de setembro de 2017', ''),
(2695, '06/09/2017', '018523/17-90', 'Construções Complano LTDA', '', '06/09/2017', '15/09/2017', '', '', 'Há certidão positiva de débitos trabalhistas', '', '18/09/2017', '', 'Email enviado para empresa em 18 de setembro de 2017', ''),
(2696, '20/09/2017', '999999/99-99', 'Sodexo do Brasil Comercial', '', '20/09/2017', '', '', '', 'Falta procuração da empresa para Elizabeth Kelly Saez', '', '20/09/2017', '', 'Email enviado para empresa em 20 de setembro de 2017', ''),
(2697, '24/07/2017', '015204/17-22', 'INFOMARKET LTDA ME', '', '24/07/2017', '27/07/2017', '', '', 'PENDENCIA VIDE PARECER', '', '', '', '', ''),
(2715, '15/09/2017', '019129/17-79', 'Universidade Federal de Campina Grande', '', '15/09/2017', '26/09/2017', '', '', 'Alterar cláusulas do contrato. Email enviada a empresa em 26 de setembro de 2017.', '', '', '', 'Tornado sem efeito. Aberto outro processo em 2018.', ''),
(2721, '19/10/2017', '021744/17-', 'Aldeota Educação Profissional LTDA', '', '19/10/2017', '', '', '', '', '', '', '', '', ''),
(2722, '13/10/2017', '021333/17-50', 'Universidade de Pernambuco - UPE', '', '13/10/2017', '10/01/2018', '', '', 'Enviado email para UPE. A Procuradoria só aceita o nosso modelo de convênio recíproco.', '', '20/10/2017', '10/01/2018', '', ''),
(2723, '27/10/2017', '021744/17-45', 'Aldeota Educação Profissional LTDA', '', '19/10/2017', '27/10/2017', '', '', 'PLANO DE ATIVIDADES; FGTS; DIVIDAS TRABALHISTAS', '', '27/10/2017', '', '', ''),
(2724, '19/10/2017', '021754/17-81', 'D M de Oliveira Portela', '', '19/10/2017', '27/10/2017', '', '', 'FGTS; TRIBUTOS FEDERAIS', '', '27/10/2017', '', '', ''),
(2727, '04/10/2017', '020540/17-97', 'Devry Educacional do Brasil S/A', '', '04/10/2017', '10/10/2017', '', '', 'Falta procuração do subscritor e relação dos diretores', '', '', '', '', ''),
(2737, '17/11/2017', '023700/17-50', 'Hospital Geral de Fortaleza 10a Regiao Militar', '09.560.963/0001-14', '17/11/2017', '22/11/2017', '11/01/2017', '', 'Entregue a Professora Renata para o Comandante da Base Aerea assinar', '', '', '', '', ''),
(2732, '18/09/2017', '019263/17-20', 'Solicitação de Contrato de Seguro para os Estudantes', '', '08/11/2017', '', '', '', '', '', '', '', '', 'Processo Renovacao Seguro Estudantes 019263-2017-70.pdf'),
(2736, '21/11/2017', '024001/17-27', 'Procuradoria Regional do Trabalho da 7ª Região', '26.989.715/0038-02', '21/11/2017', '28/11/2017', '', '', 'HÁ DÉBITO COM A RECEITA FEDERAL', '', '', '', '', ''),
(2739, '22/01/2018', '009260/18-17', 'GEOPLAN - CONSULTORIA, MEIO AMBIENTE E SERVIÇOS LTDA - EPP', '08.864.791/0001-00', '26/02/2018', '', '', '', '', '', '', '', '', ''),
(2740, '24/08/2018', '051803/18-91', 'Hospital Municipal de Anicuns', '02.262.368/0001-53', '24/08/2018', '27/08/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2741, '24/04/2018', '025292/18-51', 'Projeto União', '11.087.905/0001-67', '24/04/2018', '27/04/2018', '27/04/2018', '', '', '', '', '', '', ''),
(2742, '08/10/2018', '061335/18-62', 'Instituto Educacional e Tecnológico de Quixadá', '15.449.542/0001-13', '08/10/2018', '09/10/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2743, '08/10/2018', '061499/18-90', 'Hospital Estadual Dirceu Arcoverde', '06.553.564/0155-93', '08/10/2018', '09/10/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2744, '09/10/2018', '061795/18-91', 'Industria e Comercio de Produtos da Amazonia', '31.346.263/0001-80', '09/10/2018', '10/10/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2745, '10/05/2018', '029097/18-09', 'ACCENTURE DO BRASIL LTDA', '96.534.094/0001-58', '24/07/2018', '27/07/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2746, '03/10/2018', '061485/18-76', 'GND AGENTE AUTONOMO DE INVESTIMENTOS LTDA', '10.515.895/0001-50', '08/10/2018', '08/10/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2747, '06/11/2018', '066236/18-77', 'Prefeitura Municipal de Caucaia SEINFRA', '07.616.162/0001-06', '06/11/2018', '12/11/2018', '', '', 'O Convenio deve ser realizado com a prefeitura; falta procuração do secretário.', '', '', '', '', ''),
(2748, '27/08/2018', '052528/18-22', 'Rede Independente de Jornais do Nordeste LTDA', '07.038.870/0001-07', '28/08/2018', '30/08/2018', '', '', 'AGUARDANDO COUMENTAÇÃO COMPLEMENTAR (REGULARIZAÇÃO DE REPRESENTAÇÃO E CERTIDOES)', '', '', '', '', ''),
(2749, '24/12/2018', '078904/18-17', 'Can Pack Brasil Industria de Embalagens', '14.855.630/0001-52', '24/12/2018', '27/12/2018', '', '', 'FALTA PROCURAÇÃO DO SUBSCRITOR', '', '', '', '', ''),
(2750, '24/07/2018', '027606/18-51', 'Secretaria de Estado da Saúde da Paraíba', '08.778.268/0001-60', '24/07/2018', '08/08/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2751, '23/05/2018', '032536/18-52', 'Instituto de Saúde e Gestão Hospitalar Internato', '05.268.526/0001-70', '24/05/2018', '06/06/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2752, '23/05/2018', '032528/18-14', 'Instituto de Saúde e Gestão Hospitalar', '05.268.526/0001-70', '24/05/2018', '06/06/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2753, '23/03/2018', '016053/18-19', 'Jecev Industria de Cosmeticos LTDA', '10.659.814/0001-96', '23/03/2018', '10/04/2018', '', '', 'AGUARDANDO DOCUMENTAÇÃO COMPLEMENTAR', '', '', '', '', ''),
(2754, '23/01/2019', '003095/18-62', 'Academias GreenLife Rui Barbosa Eireli', '30.512.539/0001-90', '23/01/2019', '25/01/2019', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2755, '20/04/2018', '023382/18-62', 'Sec. de Educação do Estado do Ceará', '07.954.514/0001-25', '20/04/2018', '20/04/2018', '23/04/2018', '', 'Aguardando via UFC', '', '', '', '', ''),
(2756, '17/08/2018', '050957/18-65', 'Servico Geologico do Brasil - CPRM', '00.091.652/0001-89', '21/08/2018', '22/08/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2757, '16/03/2018', '014768/18-29', 'Prefeitura Municipal de Santana do Acaraú', '07.598.659/0001-30', '21/03/2018', '25/04/2018', '', '', 'AGUARDANDO DOCUMENTAÇÃO COMPLEMENTAR', '', '', '', '', ''),
(2758, '03/04/2018', '018225/18-81', 'Wall Jobs Tecnologia Ltda ME', '23.251.141/0001-82', '03/04/2018', '04/04/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2759, '05/03/2018', '011148/18-38', 'Esmaltec Eletrodoméstico', '02.948.030/0002-30', '05/03/2018', '06/03/2018', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2760, '05/07/2018', '041452/18-18', 'Sol e Água Indústria de Confecções LTDA', '13.088.491/0001-16', '06/07/2018', '09/07/2018', '', '', 'Documentação complementar solicitada à empresa via e-mail em 10/07', '', '', '', '', ''),
(2761, '09/07/2018', '013959/18-73', 'Município de Caucaia', '07.616.162/0001-06', '09/07/2018', '12/07/2018', '', '', 'Aguardando devolução da documentação assinada pelo Município', '', '', '', '', ''),
(2762, '10/01/2019', '000928/19-33', 'Comando do Exército Brasileiro - 10º Região Militar', '09.560.963/0001-14', '10/01/2019', '14/01/2018', '14/01/2018', '', 'Aguardando Via UFC', '', '', '', '', ''),
(2763, '10/05/2018', '029234/18-05', 'Secretaria de Agropecuária, Pesca e Recursos Hídricos - SEAGRO', '10.380.608/0001-42', '10/05/2018', '14/05/2017', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2764, '13/12/2018', '076348/18-36', 'Bahiana Distribuidora de Gás', '46.395.687/0043-61', '13/12/2018', '', '', '', 'PENDENCIA DOCS com documentos diferentes', '', '', '', '', ''),
(2765, '11/02/2019', '006770/19-73', 'Lucas Leandro Bezerra Coutinho MEI', '18.409.400/0001-42', '11/02/2019', '', '', '', 'PENDENCIA NA CERTIDAO RECEITA REENV PROC', '', '', '', '', ''),
(2767, '11/01/2019', '001325/19-59', 'Centro de Integração Empresa Escola (CIEE)-Rio de Janeiro', '33.661.745/0001-50', '01/02/2019', '', '', '', 'Aguardando documentação complementar', '', '', '', '', ''),
(2770, '21/02/2019', '009486/19-91', '2MGA Contabilidade, Assessoria e Auditoria', '03.301.516/0001-64', '21/02/2019', '', '', '', 'Documentação com CNPJs diferentes.', '', '', '', '', ''),
(2773, '20/03/2019', '011990/19-51', 'Universidade Federal do Oeste do Pará', '11.118.393/0001-59', '20/03/2019', '26/03/2019', '27/03/2019', '28/03/2019', 'FALTA VIA ASSINADA QUE FOI ENVIADA A SANTAREM PARÁ', '', '', '', '', ''),
(2772, '11/03/2019', '012575/19-14', 'ISGH', '05.268.526/0001-70', '11/03/2019', '13/03/2019', '', '', 'Procuração Vencida', '', '', '', '', '');
