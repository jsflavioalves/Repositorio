-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:40 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `check_list_TC`
--

CREATE TABLE IF NOT EXISTS `check_list_TC` (
  `Nome_Alu` varchar(80) NOT NULL,
  `Matrícula_Alu` varchar(8) NOT NULL,
  `TCE 3 vias` varchar(1) NOT NULL,
  `Plano` varchar(1) NOT NULL,
  `Vigêcia` varchar(23) NOT NULL,
  `Retroativo` varchar(1) NOT NULL,
  `Carga Horaria` varchar(2) NOT NULL,
  `CH 30 Sem/6d` varchar(1) NOT NULL,
  `Choque Horario` varchar(1) NOT NULL,
  ` Contraprestação` varchar(2) NOT NULL,
  `Auxílio-transporte` varchar(2) NOT NULL,
  `Estágio Obrigatório` varchar(1) NOT NULL,
  `Matriculado Estágio Obrigatório` varchar(2) NOT NULL,
  `Vigência período letivo` varchar(2) NOT NULL,
  `Reprovação por falta` varchar(1) NOT NULL,
  `Seguro APÓLICE` varchar(1) NOT NULL,
  `Assinatura Prof_Orientador` varchar(1) NOT NULL,
  `Exigir assinatura do aluno!` varchar(1) NOT NULL,
  `Possui convênio vigente` varchar(2) NOT NULL,
  `Atividades semestral em dia` varchar(2) NOT NULL,
  `Nome do Avaliador do TCE` varchar(80) NOT NULL,
  `Data termo devidamente corrigido` varchar(80) NOT NULL,
  `Como finalizou o atendimento` varchar(1) NOT NULL,
  `Observações canhoto` varchar(80) NOT NULL,
  `seq` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`seq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `check_list_TC`
--

