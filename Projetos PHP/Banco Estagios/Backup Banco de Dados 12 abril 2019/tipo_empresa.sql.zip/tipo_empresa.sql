-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:08 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_empresa`
--

CREATE TABLE IF NOT EXISTS `tipo_empresa` (
  `id_tipo_empresa` int(10) NOT NULL auto_increment,
  `nome` varchar(100) collate utf8_unicode_ci NOT NULL,
  `sigla` varchar(10) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_tipo_empresa`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=112 ;

--
-- Extraindo dados da tabela `tipo_empresa`
--

INSERT INTO `tipo_empresa` (`id_tipo_empresa`, `nome`, `sigla`) VALUES
(1, 'ONG/OSCIP', 'ONG'),
(2, 'Mista', 'MIS'),
(3, 'Privada', 'PRIV'),
(4, 'Pública', 'PUB'),
(5, 'Agente de Integração', 'A I'),
(6, 'Federal', 'FED'),
(7, 'Estadual', 'EST'),
(8, 'Municipal', 'MUN'),
(9, 'Empresas/Industrias', 'E/I'),
(10, 'Org. Internacionais', 'OI'),
(11, 'Sindical/Patronal', 'SP'),
(12, 'Outras', 'OUT'),
(13, 'Profissional Liberal', 'ProfLib'),
(16, 'Micro Empreendor Individual', 'MEI'),
(17, 'Micro Empresa', 'ME');
