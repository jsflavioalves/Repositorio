-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:36 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamentos`
--

CREATE TABLE IF NOT EXISTS `agendamentos` (
  `id_agendamento` int(11) NOT NULL auto_increment,
  `matricula_aluno` varchar(30) NOT NULL,
  `nome_aluno` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `data` varchar(20) NOT NULL,
  `hora` varchar(10) NOT NULL,
  PRIMARY KEY  (`id_agendamento`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=223 ;

--
-- Extraindo dados da tabela `agendamentos`
--

INSERT INTO `agendamentos` (`id_agendamento`, `matricula_aluno`, `nome_aluno`, `telefone`, `email`, `data`, `hora`) VALUES
(8, '361055', 'ROGERIO TEIXEIRA MASIH', '(85) 98897-9644', 'ROGERIOMASIH@GMAIL.COM', '01/09/2017', '09:20'),
(19, '387102', 'DANILA DIAS CORDEIRO', '(85) 98859-2801', 'daniladiascordeiro@gmail.com', '06/10/2017', '08:00'),
(116, '418331', 'KALEL PORTELA DE VASCONCELOS DOS SANTOS', '(85) 98593-2869', 'KALELPOPO@GMAIL.COM', '03/05/2018', '16:20'),
(115, '430175', 'FERNANDA NUNES OLIVEIRA', '(85) 98698-9566', 'fernanda.no92@gmail.com', '02/05/2018', '08:00'),
(43, '380838', 'ANA CAROLINA FECHINE SILVA', '(88) 99610-8369', 'carolfechine@yahoo.com.br', '23/01/2018', '12:00'),
(44, '364075', 'JOãO BARRETO DUARTE NETO', '(85) 98878-7457', 'joaobarretomecufc@gmail.com', '23/01/2018', '16:00'),
(91, '359085', 'LUANA CARMEN BARROSO RODRIGUES', '(85) 99795-3933', 'lluanabarroso@hotmail.com', '16/04/2018', '08:40'),
(113, '0383707', 'PATRICIA FERREIRA LIMA', '(85) 988448973', 'patriciafelima@gmail.com', '03/05/2018', '13:40'),
(50, '349081', 'BEATRIZ PONTES VANDERLEI', '(85) 99739-0712', 'beatrizpontes@msn.com', '21/02/2018', '09:00'),
(107, '374772', 'VANESSA DE OLIVEIRA SILVA', '(85) 98956-3641', 'vanessa.oliveira1008@gmail.com', '24/04/2018', '08:20'),
(56, '391379', 'FRANCISCO YURI MARTINS COSTA ', '(85) 99741-4069', 'yurimartc@gmail.com', '16/03/2018', '08:20'),
(55, '406621', 'JONAS DOS SANTOS MONTEIRO', '(85) 98956-2642', 'JONASDSMONTEIRO@GMAIL.COM', '13/03/2018', '11:40'),
(99, '367719', 'ANA CAROLINA ARAúJO DE CARVALHO', '(85) 98674-1985', 'carolinacarvalhoana@gmail.com', '23/04/2018', '12:00'),
(89, '407795', 'NATHALIA DA SILVA MONTEIRO', '(85) 99968-3441', 'nathalia.s.m@live.com', '16/04/2018', '09:00'),
(60, '0204838', 'IZYS BEZERRA PESSOA', '(85) 98790-0480', 'izysbezerra@yahoo.com.br', '23/04/2018', '10:00'),
(96, '374311', 'CIBELLY DA SILVA CHAVES', '(85) 98829-5232', 'cibellyschaves@gmail.com', '17/04/2018', '09:00'),
(94, '381852', 'RENAGILA DE SOUSA MENEZES', '(85) 99291-6318', 'renagilasousa@hotmail.com', '23/04/2018', '14:00'),
(93, '364707', 'LIVIA DE SOUSA LIMA', '(85) 99634-8609', 'livialima.sga@gmail.com', '16/04/2018', '11:00'),
(92, '391773', 'MERCIA ROCHA DE LIMA', '(85) 98710-0960', 'limamer.cool@gmail.com', '17/04/2018', '15:40'),
(219, '', '', '', '', '//2018', ''),
(172, '422720', 'ANDREZA MACIEL ROCHA', '(85) 32252-878', 'andrezamaciel2@hotmail.com', '17/08/2018', '12:40'),
(131, '367993', 'JOAO CARLOS FERNANDES JUCÁ', '(85) 99865-2606', '19joaocarlos19@gmail.com', '19/05/2018', '11:00'),
(109, '375866', 'TEOGENES SILVA PEIXOTO', '(85) 98805-8988', 'teogenes.peixoto@alu.ufc.br', '25/04/2018', '12:00'),
(103, '384086', 'LARISSA MARTINS DA SILVA', '(85) 99157-5056', 'martinslarissa179@gmail.com', '23/04/2018', '13:00'),
(106, '386247', 'JOAO VICTOR DELFINO MENESES', '(85) 98582-0439', 'jvictordmeneses@gmail.com', '24/04/2018', '08:20'),
(100, '345326', 'MATHEUS FONTENELLE SIQUEIRA', '(85) 98111-2123', 'matheusfsiqueira@gmail.com', '24/04/2018', '08:00'),
(133, '386258', 'MATHEUS CARDOSO DE ANDRADE ', '(85) 98993-1786', 'matheusktkt@gmail.com', '30/05/2018', '08:00'),
(173, '368317', 'CLAUDIANE CARVALHO BESSA', '(85) 98577-1619', 'CLAUDIANE.CARVALHO3263@GMAIL.COM', '20/08/2018', '15:00'),
(117, '354973', 'LIDIANNE MOREIRA FONTENELE DE ALBUQUERQUE', '(85) 32121-919', 'lidiannealbuquerque@gmail.com', '07/05/2018', '13:00'),
(122, '335962', 'GILDA CELESTE AMORIM', '(85) 99666-0326', 'gildaceleste@gmail.com', '08/05/2018', '12:00'),
(124, '379181', 'JESSYCA KELLY OLIVEIRA', '(85) 98914-0169', 'jessyca.koc@gmail.com', '10/05/2018', '10:20'),
(216, '362520', 'MATHIAS COELHO BATISTA', '(85) 98764-5340', 'mathiascoelhocnpq02@gmail.com', '29/08/2018', '09:20'),
(156, '421830', 'RENAN COELHO PINHEIRO', '(85) 98617-5824', 'coelho-rp@live.com ', '16/07/2018', '11:20'),
(126, '376808', 'FRANCISCO DIEGO MOREIRA FEITOSA', '(85) 98818-5295', 'diegomoreira@alu.ufc.br', '14/05/2018', '08:00'),
(127, '', '', '', '', '//2018', ''),
(132, '', '', '', '', '//2018', ''),
(135, '400110', 'JENNYFER CRISTINA DE MORAES SILVA', '(85) 999244911', 'JENNYFER_MS@HOTMAIL.COM', '30/05/2018', '09:40'),
(136, '', '', '', '', '//2018', ''),
(145, '397250', 'TATIANE GOMES DA SILVA', '(85) 99810-2236', 'gomes.tatiane@yahoo.com', '03/07/2018', '15:00'),
(141, '363136', 'BRUNO RICARTH DOMICIANO', '(85) 99817-3708', 'brunordomiciano@gmail.com', '01/07/2018', '09:00'),
(143, '', '', '', '', '//2018', ''),
(144, '', '', '', '', '//2018', ''),
(146, '', '', '', '', '//2018', ''),
(147, '396435', 'FELYPE DE CASTRO BASTOS', '(85) 99962-3357', 'felypecbastos@gmail.com', '02/07/2018', '09:00'),
(148, '375333', 'LUCAS MESQUITA PAIVA MARTINS', '(85) 99614-8484', 'lucasmpm97@gmail.com', '03/07/2018', '10:40'),
(149, '', '', '85996148484', 'LUCASMPM97@GMAIL.COM', '//2018', ''),
(150, '', '', '85996148484', 'LUCASMPM97@GMAIL.COM', '//2018', ''),
(165, '', '', '', '', '//2018', ''),
(166, '', '', '', '', '//2018', ''),
(167, '', '', '', '', '//2018', ''),
(171, '394127', 'LEONARDO ANTONIO SOUSA CABRAL', '(85) 98825-7594', 'leo.asc2010@gmail.com', '17/08/2018', '13:20'),
(154, '384406', 'LUIS AUGUSTO MELO DE AQUINO', '(85) 99693-2047', 'LUIAUGUSTO9@GMAIL.COM', '16/07/2018', '10:40'),
(155, '375337', 'MAYRA COSTA VIANA SILVA', '(85) 99928-2111', 'mayracviana@gmail.com', '13/07/2018', '08:00'),
(163, '', '', '', '', '//2018', ''),
(162, '370068', 'TITO LIVIO DE MIRANDA PINTO FILHO', '(85) 99959-9714', 'titolmpf@gmail.com', '31/07/2018', '09:20'),
(164, '374091', 'GUSTAVO FLORINDO DO NASCIMENTO', '(85) 99294-7661', 'gustavoflorindo01@outlook.com', '31/07/2018', '09:40'),
(212, '357659', 'RAISSA FEITOSA BEZERRA', '(85) 99148-9009', 'raissabzrr@gmail.com', '27/08/2018', '08:40'),
(175, '362527', 'SARA FERREIRA PIRES', '(85) 99847-3277', 'SARAPIRES.UFC@GMAIL.COM', '22/08/2018', '10:00'),
(176, '368318', 'GABRIELLY OLIVEIRA DA SILVA', '(85) 98818-2659', 'gabiinu1@gmail.com', '20/08/2018', '15:00'),
(179, '346403', 'DEBORAH DOUGLAS DAMASCENO AMORIM', '(85) 99659-5835', 'deborahdouglas@alu.ufc.br', '23/08/2018', '13:40'),
(207, '', '', '', 'MATHIASCOELHO@ALU.UFC.BR', '//2018', ''),
(215, '362503', 'CRISTIANO SILVA DO NASCIMENTO', '(85) 98756-9731', 'cristianoxd102@gmail.com', '28/08/2018', '16:20'),
(200, '366912', 'DIEGO COUCEIRO DE MEDEIROS', '(85) 99668-0457', 'diegocmedeiros7@gmail.com', '24/08/2018', '08:00'),
(196, '357618', 'ANA BEATRIZ RIPARDO ARAúJO', '(85) 98413-2554', 'anabeatrizripardo@gmail.com', '23/08/2018', '09:40'),
(185, '362524', 'RAQUEL CAMINHA DANTAS', '(85) 30234-390', 'raqueldantas.rcd@gmail.com', '24/08/2018', '09:00'),
(186, '362522', 'PâMELLA LUIZA SANTOS DA SILVA', '(85) 98682-1477', 'pamellaufc@gmail.com', '22/08/2018', '15:00'),
(188, '357645', 'LARISSA DA SILVA CHICAS', '(85) 32526-496', 'larissa_chicas@hotmail.com', '22/08/2018', '12:00'),
(190, '357657', 'PAULO RAFAEL LIMA DE MEDEIROS', '(85) 99767-1839', 'r_afa_medeiros@hotmail.com', '23/08/2018', '16:00'),
(191, '373617', 'ARIANY LIMA SOUSA TORRES', '(85) 99841-8054', 'arianylst@gmail.com', '27/08/2018', '15:20'),
(192, '', '', '', 'MATHIASCOELHO@ALU.UFC.BR', '//2018', ''),
(193, '371718', 'MARIA JAMILI SOUSA SILVA', '(85) 99229-1087', 'jamilisousa@alu.ufc.br', '23/08/2018', '10:00'),
(194, '363807', 'BRENDA MIKAELLY VEIGA DA SILVA', '(85) 98594-3049', 'brendah.mikaelly@gmail.com', '22/08/2018', '15:00'),
(208, '349924', 'KAREN ALESSANDRA COUTINHO RODRIGUES', '(85)988093509', 'KARENCOUTINHO@YMAIL.COM', '28/08/2018', '14:20'),
(205, '', '', '', 'MATHIASCOELHO@ALU.UFC.BR', '//2018', ''),
(198, '373627', 'FRANCISCO LENNON CAMILO ROSA', '(85) 99719-6486', 'lennoncamilobiotec@gmail.com', '24/08/2018', '10:00'),
(213, '372960', 'GABRIEL ARAUJO SABOYA', '(85) 99610-9651', 'gabriel_a_saboya@hotmail.com', '27/08/2018', '10:40'),
(217, '', '', '', '', '//2018', ''),
(222, '', '', '', '', '//2018', '');
