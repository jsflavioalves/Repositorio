-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:43 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `convenios_arquivados`
--

CREATE TABLE IF NOT EXISTS `convenios_arquivados` (
  `id_convenios_arquivados` int(10) NOT NULL auto_increment,
  `dt_abertura` varchar(10) collate utf8_unicode_ci NOT NULL,
  `processo` varchar(50) collate utf8_unicode_ci NOT NULL,
  `interessado` varchar(200) collate utf8_unicode_ci NOT NULL,
  `cnpj` varchar(100) collate utf8_unicode_ci NOT NULL,
  `saida_procuradoria` varchar(10) collate utf8_unicode_ci NOT NULL,
  `retorno_procuradoria` varchar(10) collate utf8_unicode_ci NOT NULL,
  `saida_prex` varchar(10) collate utf8_unicode_ci NOT NULL,
  `retorno_prex` varchar(10) collate utf8_unicode_ci NOT NULL,
  `pendencia` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data_arquivamento` varchar(30) collate utf8_unicode_ci NOT NULL,
  `observacao` varchar(100) collate utf8_unicode_ci NOT NULL,
  `status` varchar(30) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_convenios_arquivados`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2688 ;

--
-- Extraindo dados da tabela `convenios_arquivados`
--

INSERT INTO `convenios_arquivados` (`id_convenios_arquivados`, `dt_abertura`, `processo`, `interessado`, `cnpj`, `saida_procuradoria`, `retorno_procuradoria`, `saida_prex`, `retorno_prex`, `pendencia`, `data_arquivamento`, `observacao`, `status`) VALUES
(2673, '02/12/2010', '24083/10-62', 'Empresa de Assistência Técnica e Extensão Rural do Ceará', '', '10/12/2010', '', '', '', '', '', '', ''),
(2674, '08/11/2011', '24195/11-77', 'Faculdade de Ciências Farmacêuticas de Ribeirão Preto', '', '', '', '', '', '', '', '', ''),
(2672, '05/08/2009', '15679/09-38', 'Procuradoria Geral do Estado', '', '09/09/2017', '', '', '', '', '23/08/2017', 'arquivado por inércia do requerente', ''),
(2675, '10/10/2011', '21279/11-40', 'Universidade de São Paulo', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2676, '19/05/2011', '10239/11-72', 'R.B Comércio e Indústria Ltda', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2677, '11/07/2012', '15510/12-92', 'PR Assessoria de Transportes e Serviços', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2678, '18/06/2012', '14238/12-32', 'Prefeitura Municipal de Aurora', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2679, '15/03/2012', '6696/12-61', 'Empresa Brasileira de Correios e Telégrafos', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2680, '02/02/2012', '14843/12-40', 'Prefeitura Municipal de Ipueiras', '', '', '', '', '', '', '', 'arquivado por inércia do requerente', ''),
(2682, '24/07/2017', '015176/17-43', 'EMPRESA BRASILEIRA DE PESQUISA AGROPACUÁRIA - EMBRAPA CAMPO GRANDE/MS', '', '24/07/2017', '02/08/2017', '', '', 'Débitos trabalhistas - certidão positiva - enviado email em 02 de ago 2017', '', '', ''),
(2683, '04/04/2017', '007011/17-06', 'Hélida Melo Conrado Fernandes', '', '04/04/2017', '12/04/2017', '', '', 'Falta declaração de insenção do FGTS', '', '', '');
