-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:01 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `Relatorio_Ativ`
--

CREATE TABLE IF NOT EXISTS `Relatorio_Ativ` (
  `Nome_Alu` varchar(80) NOT NULL,
  `Matrícula_Alu` varchar(8) NOT NULL,
  `Avaliar Relatório Ativ` varchar(1) NOT NULL,
  `Nome Avaliador` varchar(80) NOT NULL,
  `Observações feitas canhoto` varchar(80) NOT NULL,
  `seq` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`seq`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `Relatorio_Ativ`
--

