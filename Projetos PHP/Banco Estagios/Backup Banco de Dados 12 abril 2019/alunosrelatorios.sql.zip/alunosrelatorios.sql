-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:39 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunosrelatorios`
--

CREATE TABLE IF NOT EXISTS `alunosrelatorios` (
  `Código` int(11) NOT NULL auto_increment,
  `Matricula` varchar(10) NOT NULL,
  `Semestre` varchar(5) NOT NULL,
  `DT_ENTREGA` datetime default NULL,
  KEY `Matricula` (`Matricula`),
  KEY `Semestre` (`Semestre`),
  KEY `Código` (`Código`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Extraindo dados da tabela `alunosrelatorios`
--

INSERT INTO `alunosrelatorios` (`Código`, `Matricula`, `Semestre`, `DT_ENTREGA`) VALUES
(3, '14024', '20142', '2014-09-15 00:00:00'),
(19, '7123', '6', '2012-12-04 00:00:00'),
(38, '7123', '20122', '2012-12-04 00:00:00'),
(20, '762', '9', '2012-09-18 00:00:00'),
(4, '7759', '20121', '2012-06-26 00:00:00'),
(6, '7764', '8', '2011-03-31 00:00:00'),
(33, '7906', '7', '2011-08-31 00:00:00'),
(8, '7962', '4', '2011-04-19 00:00:00'),
(13, '8119', '5º', '2011-08-04 00:00:00'),
(18, '8271', '8º', '2011-08-01 00:00:00'),
(10, '8275', '4', '2011-05-27 00:00:00'),
(16, '8362', '8º', '2011-08-01 00:00:00'),
(40, '8668', '20122', '2012-11-28 00:00:00'),
(21, '8811', '6º', '2011-08-01 00:00:00'),
(12, '8934', '20121', '2012-03-28 00:00:00'),
(5, '8997', '20131', '2013-03-18 00:00:00'),
(15, '9085', '20112', '2011-10-04 00:00:00'),
(14, '9211', '8º', '2011-11-22 00:00:00'),
(1, '9324', '20122', '2012-11-05 00:00:00'),
(11, '9414', '20112', '2011-08-18 00:00:00'),
(36, '9435', '2012.', '2012-03-16 00:00:00'),
(7, '9536', '7', '2011-08-12 00:00:00'),
(32, '9545', '20112', '2011-09-09 00:00:00'),
(29, '9550', '5', '2011-08-26 00:00:00'),
(2, '9571', '6', '2011-07-18 00:00:00'),
(17, '9847', '8º', '2011-11-22 00:00:00'),
(35, '9847', '6', '2011-11-22 00:00:00'),
(28, '9855', '6', '2011-11-17 00:00:00'),
(34, '9855', '20121', '2012-06-21 00:00:00');
