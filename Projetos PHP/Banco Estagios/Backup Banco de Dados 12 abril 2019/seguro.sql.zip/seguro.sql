-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:02 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `seguro`
--

CREATE TABLE IF NOT EXISTS `seguro` (
  `id_seguro` int(10) NOT NULL auto_increment,
  `empresa_seguradora` varchar(500) collate utf8_unicode_ci NOT NULL,
  `apolice` varchar(20) collate utf8_unicode_ci NOT NULL,
  `dt_inicio` varchar(10) collate utf8_unicode_ci NOT NULL,
  `dt_fim` varchar(10) collate utf8_unicode_ci NOT NULL,
  `morte` varchar(100) collate utf8_unicode_ci NOT NULL,
  `invalidez` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_seguro`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `seguro`
--

INSERT INTO `seguro` (`id_seguro`, `empresa_seguradora`, `apolice`, `dt_inicio`, `dt_fim`, `morte`, `invalidez`) VALUES
(1, 'ROYAL & SUNALLIANCE SEGUROS (BRASIL) SA.', '071.00982.00820-13', '28/07/2016', '28/07/2017', '20.000,00', '20.000,00');
