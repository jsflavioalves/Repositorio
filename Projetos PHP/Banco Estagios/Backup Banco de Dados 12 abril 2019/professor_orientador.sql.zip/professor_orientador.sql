-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:01 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor_orientador`
--

CREATE TABLE IF NOT EXISTS `professor_orientador` (
  `id_professor` int(11) NOT NULL auto_increment,
  `nome` varchar(200) NOT NULL,
  `siape` varchar(200) NOT NULL,
  `fone` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `lotacao` varchar(200) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_professor`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Extraindo dados da tabela `professor_orientador`
--

INSERT INTO `professor_orientador` (`id_professor`, `nome`, `siape`, `fone`, `email`, `lotacao`, `cpf`) VALUES
(21, 'FRANCISCO HEBER LACERDA DE OLIVEIRA', '2344503', '(85) 99973-0872', 'HEBER@DET.UFC.BR', 'DET', '823.086.323-72'),
(20, 'PAULA SACHA FROTA NOGUEIRA', '2650163', '(85) 99962-5489', 'SACHANOGUEIRAUFC@GMAIL.COM', 'DEPARTAMENTO DE ENFERMAGEM', '013.281.443-99'),
(19, 'ROGÉRIO TEIXEIRA MASIH', '3284295', '(85) 99987-9644', 'ROGERIOMASIH@GMAIL.COM', 'DEPRO/CT', '425.514.043-04'),
(18, 'VIVIAN MARIA SOUSA SALES', '1234567', '(85) 98717-6436', 'VIVIANSALESINFO@GMAIL.COM', 'ADMINISTRADORA', '000.222.222-22'),
(22, 'CLODOALDO DE OLIVEIRA CARVALHO FILHO', '1303438', '(85) 33669635', 'CLODOALDO@UFC.BR', 'DEPARTAMENTO DE ENGENHARIA MECÂNICA/CT', '37039733315'),
(23, 'LAMARTINE SOARES CARDOSO DE OLIVEIRA ', '2241600', '(85) 90000-0000', 'LAMARTINEUFC@GMAIL.COM', 'DEPTO DE FITOTECNIA', '056.940.284-06'),
(24, '', '', '', '', '', ''),
(25, 'NADJA GLHEUCA DA SILVA DUTRA MONTENEGRO ', '2280792', '(85) 33669-488', 'NADJA@DET.UFC.BR', 'COORD DE EXTENSAO DO CAMPUS DO PICI', '430.087.473-53'),
(26, 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP', 'ZAP'),
(27, 'PAULO RODRIGUES NUNES NETO', '4528643', '(85) 03023-8242', 'PAULO.ROG@GMAIL.COM', 'MEDICINA', '907.661.563-20');
