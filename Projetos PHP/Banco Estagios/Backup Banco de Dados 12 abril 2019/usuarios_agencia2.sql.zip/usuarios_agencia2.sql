-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 11:09 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios_agencia2`
--

CREATE TABLE IF NOT EXISTS `usuarios_agencia2` (
  `id_user` int(11) NOT NULL auto_increment,
  `nome` varchar(100) collate utf8_unicode_ci NOT NULL,
  `login` varchar(100) collate utf8_unicode_ci NOT NULL,
  `senha` varchar(100) collate utf8_unicode_ci NOT NULL,
  `tipo_usuario` varchar(20) collate utf8_unicode_ci NOT NULL,
  `funcao` varchar(100) collate utf8_unicode_ci NOT NULL,
  `perfil` varchar(200) collate utf8_unicode_ci NOT NULL,
  `status` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=92 ;

--
-- Extraindo dados da tabela `usuarios_agencia2`
--

INSERT INTO `usuarios_agencia2` (`id_user`, `nome`, `login`, `senha`, `tipo_usuario`, `funcao`, `perfil`, `status`) VALUES
(2, 'Rafaela dos Reis', 'rafaelarodrigues', '653.085.303-00', 'administrador', 'Auxiliar Administrativa', 'user_padrao.jpg', 'Autorizado'),
(4, 'Flavio Alves', 'flavio', '457.676.613-91', 'administrador', 'Administrador', 'Flavio.jpg', 'Autorizado'),
(5, 'Monica Monteiro', 'monica', '110.516.983-91', 'administrador', 'Vice-Coordenadora', 'user_padrao.jpg', 'Autorizado'),
(7, 'Carlos Vasconcelos', 'jcvmendes', '234.468.623-15', 'administrador', 'Auxiliar Administrativo', 'user_padrao.jpg', 'Autorizado'),
(21, 'Rogério Masih', 'rogerio', '425.514.043-04', 'administrador', 'Chefe', 'user_padrao.jpg', 'Autorizado'),
(31, 'Felipe da silva santos', '888888', '078.533.383-50', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(32, 'arthur alam araújo oliveira', '373856', '051.610.203-69', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(33, 'Wesley vieira da silva', '384265', '065.938.733-65', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(34, 'ROGERIO TEIXEIRA ', '666666', '887.888.808-02', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(41, 'FELIPE', '11.111.111/1111-11', '12345678', 'empresa', '', 'user_padrao.jpg', 'Autorizado'),
(39, 'Matheus fontenelle siqueira', '345326', '059.084.123-84', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(40, 'Francisca ronielly sousa matos', '20141001211', '053.497.593-37', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(42, 'roberto', 'roberto', '111.111.111-11', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(44, 'Marcos André Forte Morais', '376823', '032.873.343-10', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(45, 'Giovanni da Silva Santos', '3431277', '078.533.383-50', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(48, 'Luciano Santana da Silva filho', '406688', '60650739388', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(49, 'MANOEL ALVES DA SILVA', '364472', '194.903.803-34', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(50, 'DANIEL FRANCISCO BARBOSA MURO', '367471', '050.722.573-20', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(65, 'ROGERIO TEIXEIRA MASIH', '361055', '425.514.043-04', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(64, 'Thalyta Alencar de Carvalho', '379014', '062.550.053-99', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(68, 'FRANCISCO MARCELO PEREIRA SILVA', '327875', '366.548.413-87', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(67, 'emma sousa sales', '1234', '077.288.283-00', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(69, 'Rebecca Lustosa Lira', 'rebecca', '024.879.133-80', 'administrador', 'assistente', 'user_padrao.jpg', 'Autorizado'),
(72, 'Pedro Adriel de Castro Rodrigues', '13210588', '058.681.713-14', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(71, 'REBECA SOUSA', '345600', '000.111.222-01', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(73, 'rogerio agronomia teste', '04072017', '000.000.000-00', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(75, 'DANILA DIAS CORDEIRO', '387102', '016.053.443-70', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(76, 'CARLOS EVERSSON CAVALCANTE DA SILVA', '3474800', '999.999.999-99', 'aluno', '', 'user_padrao.jpg', 'Autorizado'),
(77, 'Anna Karoline caminha de araújo', '367426', '063.147.473-09', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(78, 'Gabriel alves paiva', '364015', '049.172.213-31', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(79, 'RENDA ASSET ADMINISTRADORA DE RECURSOS', '10.253.634/0001-00', 'renda3047', 'empresa', '', 'user_padrao.jpg', 'Pendente'),
(80, 'YURI', 'YuriJM', '111', 'administrador', 'assistente', 'user_padrao.jpg', 'Autorizado'),
(81, 'LUCAS ALEXANDRE DAMASCENO', '385923', '607.595.293-45', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(82, 'Renan Silva Galeno', '374895', '063.967.303-16', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(86, 'Eudemberg monteiro da Silva', '391373', '035.525.223-60', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(89, 'EVERSSON SILVA', '2009123', '066.060.813-86', 'professor', '', 'user_padrao.jpg', 'Autorizado'),
(87, 'Pedro henrique carvalho dos santos', '369841', '608.656.333-04', 'aluno', '', 'user_padrao.jpg', 'Pendente'),
(91, 'Carlos jefferson sales costa', '376160', '049.891.593-06', 'aluno', '', 'user_padrao.jpg', 'Pendente');
