-- phpMyAdmin SQL Dump
-- version 2.11.8.1deb5+lenny4
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Abr 12, 2019 as 10:58 AM
-- Versão do Servidor: 5.0.51
-- Versão do PHP: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `estagios`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `preceptores`
--

CREATE TABLE IF NOT EXISTS `preceptores` (
  `id_preceptor` int(11) NOT NULL auto_increment,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(30) NOT NULL,
  PRIMARY KEY  (`id_preceptor`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `preceptores`
--

INSERT INTO `preceptores` (`id_preceptor`, `nome`, `cpf`) VALUES
(2, 'FELIPE DA SILVA SANTOS', '078.533.383-50');
